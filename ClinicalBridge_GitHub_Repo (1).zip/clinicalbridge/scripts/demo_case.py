"""
ClinicalBridge - Demo Script
Run this for the hackathon demo. Simulates a real prior auth request.
"""

import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.agents.intake_agent import run_intake_agent
from src.agents.coding_agent import run_coding_agent
from src.agents.auth_agent import run_auth_agent
from src.agents.audit_agent import run_audit_agent, get_audit_trail, verify_chain

DEMO_CASE = {
    "patient_id": "P-DEMO-001",
    "proposed_procedure": "Coronary angiography",
    "payer": "PMJAY",
    "raw_notes": (
        "55 year old male presents with chest pain radiating to left arm for 2 days. "
        "Shortness of breath on exertion. Diaphoresis noted. "
        "BP 155/98 mmHg, HR 92 bpm, SpO2 95%. "
        "ECG shows ST depression in leads V4-V6. "
        "Currently on Aspirin 75mg OD, Atorvastatin 40mg OD, Metoprolol 25mg BD. "
        "History of hypertension for 5 years, Type 2 diabetes for 3 years. "
        "Family history: father had MI at age 60. "
        "Troponin I: 0.08 ng/mL (elevated). "
        "Treating physician recommends urgent coronary angiography to rule out ACS."
    ),
    "extracted_entities": None,
    "coding_result": None,
    "auth_result": None,
    "error": None
}

DIVIDER = "─" * 70


def print_section(title: str):
    print(f"\n{DIVIDER}")
    print(f"  {title}")
    print(DIVIDER)


def run_demo():
    print("\n" + "═" * 70)
    print("  ClinicalBridge — AI Prior Authorization Demo")
    print("  ET GenAI Hackathon 2026 | Problem Statement 5")
    print("═" * 70)

    state = {**DEMO_CASE}
    case_id = "CB-DEMO-20260329"

    # ── Step 1: Intake ──────────────────────────────────────────────────────
    print_section("STEP 1: Intake Agent — Clinical Note Parsing")
    state = run_intake_agent(state)

    if state.get("error"):
        print(f"ERROR: {state['error']}")
        return

    entities = state["extracted_entities"]
    print(f"\n  Symptoms extracted    : {entities.get('symptoms', [])}")
    print(f"  Medications extracted : {entities.get('medications', [])}")
    print(f"  Severity              : {entities.get('severity', 'unknown')}")
    print(f"  Duration              : {entities.get('duration', 'unknown')}")

    # ── Step 2: Coding ──────────────────────────────────────────────────────
    print_section("STEP 2: Coding Agent — ICD-10 & CPT Assignment")
    state = run_coding_agent(state)

    if state.get("error"):
        print(f"ERROR: {state['error']}")
        return

    coding = state["coding_result"]
    print(f"\n  ICD-10 Codes Assigned:")
    for code in coding.get("icd10_codes", []):
        print(f"    {code['code']:10} {code['description']} (confidence: {code['confidence']:.0%})")

    print(f"\n  CPT Codes Assigned:")
    for code in coding.get("cpt_codes", []):
        print(f"    {code['code']:10} {code['description']} (confidence: {code['confidence']:.0%})")

    print(f"\n  Overall Coding Confidence : {coding.get('overall_confidence', 0):.0%}")
    print(f"  Escalate to Human         : {coding.get('escalate_to_human', False)}")

    # ── Step 3: Auth ────────────────────────────────────────────────────────
    print_section("STEP 3: Authorization Agent — Payer Policy Check (PMJAY)")
    state = run_auth_agent(state)

    if state.get("error"):
        print(f"ERROR: {state['error']}")
        return

    auth = state["auth_result"]
    decision = auth.get("decision", "UNKNOWN")
    decision_color = {
        "APPROVED": "✅",
        "APPROVED_WITH_CONDITIONS": "✅⚠️",
        "DENIED": "❌",
        "ESCALATED_TO_HUMAN": "🔁"
    }.get(decision, "❓")

    print(f"\n  {decision_color} DECISION: {decision}")
    print(f"  Auth Confidence           : {auth.get('confidence', 0):.0%}")
    print(f"  Financial Threshold Flag  : {auth.get('financial_threshold_flag', False)}")

    if auth.get("conditions"):
        print(f"\n  Conditions:")
        for c in auth["conditions"]:
            print(f"    • {c}")

    if auth.get("denial_reasons"):
        print(f"\n  Denial Reasons:")
        for r in auth["denial_reasons"]:
            print(f"    • {r}")

    if auth.get("policy_citations"):
        print(f"\n  Policy Citations:")
        for p in auth["policy_citations"]:
            print(f"    • {p}")

    if auth.get("escalate_to_human"):
        print(f"\n  ⚠️  ESCALATION REASON: {auth.get('escalation_reason')}")

    # ── Step 4: Audit ───────────────────────────────────────────────────────
    print_section("STEP 4: Audit Agent — Immutable Decision Log")
    run_audit_agent(state, case_id)

    trail = get_audit_trail(case_id)
    is_valid, chain_msg = verify_chain(case_id)

    print(f"\n  Audit records logged : {len(trail)}")
    print(f"  Chain integrity      : {chain_msg}")

    print(f"\n  Audit Trail:")
    for record in trail:
        print(f"    [{record['timestamp'][:19]}] {record['agent']:15} | {record['action']:25} | "
              f"escalated={bool(record['escalated'])} | hash={record['record_hash'][:12]}...")

    # ── Summary ─────────────────────────────────────────────────────────────
    print_section("SUMMARY")
    print(f"\n  Case ID       : {case_id}")
    print(f"  Patient ID    : {DEMO_CASE['patient_id']}")
    print(f"  Payer         : {DEMO_CASE['payer']}")
    print(f"  Procedure     : {DEMO_CASE['proposed_procedure']}")
    print(f"  Final Decision: {decision}")
    print(f"  Audit Chain   : {'VALID ✅' if is_valid else 'INVALID ❌'}")
    print(f"\n  DISCLAIMER: Support tool only. Requires authorized human review.")
    print("\n" + "═" * 70 + "\n")


if __name__ == "__main__":
    run_demo()
