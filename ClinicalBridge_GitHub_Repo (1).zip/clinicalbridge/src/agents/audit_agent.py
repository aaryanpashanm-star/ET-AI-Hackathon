"""
ClinicalBridge - Audit Agent
Creates an immutable, hash-chained audit trail of every agent decision.
Every record is SHA-256 chained to the previous — tamper-evident by design.
"""

import hashlib
import json
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import TypedDict

AUDIT_DB_PATH = Path("data/audit.db")


class AuditRecord(TypedDict):
    record_id: str
    case_id: str
    patient_id: str
    timestamp: str
    agent: str
    action: str
    input_summary: str
    output_summary: str
    confidence: float | None
    escalated: bool
    prev_hash: str
    record_hash: str


def _get_db() -> sqlite3.Connection:
    AUDIT_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(AUDIT_DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            record_id TEXT PRIMARY KEY,
            case_id TEXT NOT NULL,
            patient_id TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            agent TEXT NOT NULL,
            action TEXT NOT NULL,
            input_summary TEXT,
            output_summary TEXT,
            confidence REAL,
            escalated INTEGER,
            prev_hash TEXT NOT NULL,
            record_hash TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def _get_latest_hash(conn: sqlite3.Connection, case_id: str) -> str:
    """Gets the hash of the most recent audit record for this case (for chaining)."""
    row = conn.execute(
        "SELECT record_hash FROM audit_log WHERE case_id = ? ORDER BY timestamp DESC LIMIT 1",
        (case_id,)
    ).fetchone()
    return row[0] if row else "GENESIS"


def _compute_hash(record: dict) -> str:
    """SHA-256 hash of the record content (excluding record_hash itself)."""
    payload = {k: v for k, v in record.items() if k != "record_hash"}
    serialized = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()


def log_audit_event(
    case_id: str,
    patient_id: str,
    agent: str,
    action: str,
    input_summary: str,
    output_summary: str,
    confidence: float | None = None,
    escalated: bool = False
) -> str:
    """
    Appends a tamper-evident audit record to the chain.
    Returns the record_id.
    """
    conn = _get_db()
    prev_hash = _get_latest_hash(conn, case_id)
    timestamp = datetime.now(timezone.utc).isoformat()
    record_id = f"AUD-{case_id}-{int(time.time()*1000)}"

    record = {
        "record_id": record_id,
        "case_id": case_id,
        "patient_id": patient_id,
        "timestamp": timestamp,
        "agent": agent,
        "action": action,
        "input_summary": input_summary,
        "output_summary": output_summary,
        "confidence": confidence,
        "escalated": int(escalated),
        "prev_hash": prev_hash,
    }

    record["record_hash"] = _compute_hash(record)

    conn.execute("""
        INSERT INTO audit_log VALUES (
            :record_id, :case_id, :patient_id, :timestamp,
            :agent, :action, :input_summary, :output_summary,
            :confidence, :escalated, :prev_hash, :record_hash
        )
    """, record)
    conn.commit()
    conn.close()

    print(f"[AuditAgent] Logged: {agent} | {action} | escalated={escalated} | hash={record['record_hash'][:12]}...")
    return record_id


def get_audit_trail(case_id: str) -> list[AuditRecord]:
    """Retrieves the full audit trail for a case."""
    conn = _get_db()
    rows = conn.execute(
        "SELECT * FROM audit_log WHERE case_id = ? ORDER BY timestamp ASC",
        (case_id,)
    ).fetchall()
    conn.close()

    columns = [
        "record_id", "case_id", "patient_id", "timestamp", "agent",
        "action", "input_summary", "output_summary", "confidence",
        "escalated", "prev_hash", "record_hash"
    ]
    return [dict(zip(columns, row)) for row in rows]


def verify_chain(case_id: str) -> tuple[bool, str]:
    """
    Verifies the hash chain integrity for a case.
    Returns (is_valid, message).
    """
    trail = get_audit_trail(case_id)
    if not trail:
        return True, "No records found."

    for i, record in enumerate(trail):
        expected_prev = "GENESIS" if i == 0 else trail[i - 1]["record_hash"]
        if record["prev_hash"] != expected_prev:
            return False, f"Chain broken at record {record['record_id']} — prev_hash mismatch"

        # Recompute hash to verify record wasn't tampered with
        check_record = {k: v for k, v in record.items() if k != "record_hash"}
        computed = _compute_hash(check_record)
        if computed != record["record_hash"]:
            return False, f"Tamper detected at record {record['record_id']}"

    return True, f"Chain valid — {len(trail)} records verified."


def run_audit_agent(state: dict, case_id: str) -> str:
    """
    Logs all agent decisions for a completed pipeline run.
    Returns the audit trail ID.
    """
    patient_id = state.get("patient_id", "UNKNOWN")

    # Log intake
    entities = state.get("extracted_entities") or {}
    log_audit_event(
        case_id=case_id, patient_id=patient_id,
        agent="IntakeAgent", action="ENTITY_EXTRACTION",
        input_summary=state.get("raw_notes", "")[:200],
        output_summary=f"Extracted {len(entities.get('symptoms', []))} symptoms, "
                       f"{len(entities.get('medications', []))} medications"
    )

    # Log coding
    coding = state.get("coding_result") or {}
    log_audit_event(
        case_id=case_id, patient_id=patient_id,
        agent="CodingAgent", action="CODE_ASSIGNMENT",
        input_summary=json.dumps(entities)[:300],
        output_summary=f"ICD-10: {[c['code'] for c in coding.get('icd10_codes', [])]} | "
                       f"CPT: {[c['code'] for c in coding.get('cpt_codes', [])]}",
        confidence=coding.get("overall_confidence"),
        escalated=coding.get("escalate_to_human", False)
    )

    # Log auth
    auth = state.get("auth_result") or {}
    log_audit_event(
        case_id=case_id, patient_id=patient_id,
        agent="AuthAgent", action="PRIOR_AUTH_DECISION",
        input_summary=f"Payer: {state.get('payer')} | Procedure: {state.get('proposed_procedure')}",
        output_summary=f"Decision: {auth.get('decision')} | "
                       f"Conditions: {len(auth.get('conditions', []))}",
        confidence=auth.get("confidence"),
        escalated=auth.get("escalate_to_human", False)
    )

    print(f"[AuditAgent] Full pipeline logged for case {case_id}.")
    return case_id
