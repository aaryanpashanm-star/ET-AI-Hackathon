"""
ClinicalBridge - Authorization Agent
Checks payer-specific prior authorization rules and makes approval decisions.
RAG over payer policy documents.
"""

from typing import TypedDict, Literal
from anthropic import Anthropic
from src.rag.retriever import retrieve_payer_policy
import json
import re

client = Anthropic()

AuthDecision = Literal["APPROVED", "APPROVED_WITH_CONDITIONS", "DENIED", "ESCALATED_TO_HUMAN"]


class AuthResult(TypedDict):
    decision: AuthDecision
    conditions: list[str]
    denial_reasons: list[str]
    policy_citations: list[str]
    confidence: float
    escalate_to_human: bool
    escalation_reason: str | None
    financial_threshold_flag: bool


class AuthAgentState(TypedDict):
    raw_notes: str
    patient_id: str
    proposed_procedure: str
    payer: str
    extracted_entities: dict
    coding_result: dict
    auth_result: AuthResult | None
    error: str | None


# Cases above this INR value require mandatory human sign-off
FINANCIAL_THRESHOLD_INR = 50_000
AUTH_CONFIDENCE_THRESHOLD = 0.80

AUTH_SYSTEM_PROMPT = """You are a prior authorization specialist for an Indian healthcare payer network.
Your job is to determine whether a proposed medical procedure qualifies for prior authorization
under the specified payer's policies.

You will receive:
1. Patient clinical summary and extracted codes
2. Relevant payer policy excerpts retrieved from our knowledge base

Decision logic:
- APPROVED: Procedure clearly meets all payer criteria, no conditions
- APPROVED_WITH_CONDITIONS: Procedure approved but requires additional documentation/steps
- DENIED: Procedure does not meet payer criteria (must cite specific policy)
- ESCALATED_TO_HUMAN: Insufficient information or edge case — do not decide unilaterally

Rules:
- NEVER deny a claim without citing a specific policy section
- NEVER approve without checking all listed criteria
- When in doubt → ESCALATED_TO_HUMAN (not DENIED)
- Always list your policy citations

Return valid JSON:
{
  "decision": "APPROVED|APPROVED_WITH_CONDITIONS|DENIED|ESCALATED_TO_HUMAN",
  "conditions": ["list of conditions if approved with conditions"],
  "denial_reasons": ["list of specific policy-based reasons if denied"],
  "policy_citations": ["list of policy sections cited"],
  "confidence": 0.0,
  "escalate_to_human": false,
  "escalation_reason": null,
  "financial_threshold_flag": false
}

COMPLIANCE: When in doubt, always escalate. Do not auto-deny edge cases."""


def run_auth_agent(state: AuthAgentState) -> AuthAgentState:
    """
    Runs the prior authorization agent.
    Retrieves payer policies via RAG and makes a compliance-gated auth decision.
    """
    print(f"[AuthAgent] Checking prior auth for payer: {state['payer']}...")

    coding_result = state.get("coding_result", {})

    # If coding was escalated, auth must also escalate
    if coding_result.get("escalate_to_human"):
        print("[AuthAgent] Coding was escalated — forcing auth escalation.")
        auth_result: AuthResult = {
            "decision": "ESCALATED_TO_HUMAN",
            "conditions": [],
            "denial_reasons": [],
            "policy_citations": [],
            "confidence": 0.0,
            "escalate_to_human": True,
            "escalation_reason": "Upstream coding agent required human review",
            "financial_threshold_flag": False
        }
        return {**state, "auth_result": auth_result, "error": None}

    icd10_codes = [c["code"] for c in coding_result.get("icd10_codes", [])]
    cpt_codes = [c["code"] for c in coding_result.get("cpt_codes", [])]

    # RAG: retrieve relevant payer policy sections
    policy_docs = retrieve_payer_policy(state["payer"], cpt_codes, icd10_codes)
    print(f"[AuthAgent] Retrieved {len(policy_docs)} policy sections.")

    prompt = f"""Payer: {state['payer']}
Proposed Procedure: {state['proposed_procedure']}

Assigned ICD-10 Codes: {icd10_codes}
Assigned CPT Codes: {cpt_codes}

Coding Rationale: {coding_result.get('coding_rationale', '')}

Clinical Summary:
{state['raw_notes'][:1000]}

Relevant Payer Policy Sections:
{json.dumps(policy_docs, indent=2)}

Make a prior authorization decision. Follow all compliance rules."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=2048,
            system=AUTH_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )

        raw_output = response.content[0].text
        cleaned = re.sub(r"```(?:json)?", "", raw_output).strip()
        auth_result: AuthResult = json.loads(cleaned)

        # Enforce confidence gate
        if auth_result.get("confidence", 0) < AUTH_CONFIDENCE_THRESHOLD:
            auth_result["escalate_to_human"] = True
            auth_result["decision"] = "ESCALATED_TO_HUMAN"
            auth_result["escalation_reason"] = (
                f"Confidence {auth_result['confidence']:.2f} below auth threshold {AUTH_CONFIDENCE_THRESHOLD}"
            )

        # Check financial threshold (placeholder — real implementation queries procedure cost DB)
        # For demo, we flag coronary angiography as above threshold
        high_cost_procedures = ["coronary angiography", "cardiac catheterization", "bypass surgery"]
        if any(p.lower() in state["proposed_procedure"].lower() for p in high_cost_procedures):
            auth_result["financial_threshold_flag"] = True

        print(f"[AuthAgent] Decision: {auth_result['decision']} | "
              f"Confidence: {auth_result.get('confidence', 0):.2f} | "
              f"Escalate: {auth_result['escalate_to_human']}")

        return {**state, "auth_result": auth_result, "error": None}

    except json.JSONDecodeError as e:
        return {**state, "error": f"AuthAgent JSON parse failed: {str(e)}"}
    except Exception as e:
        return {**state, "error": f"AuthAgent failed: {str(e)}"}
