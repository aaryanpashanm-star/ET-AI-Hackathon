"""
ClinicalBridge - Coding Agent
Assigns ICD-10-CM diagnosis codes and CPT procedure codes with confidence scores.
Uses RAG over ICD-10 and CPT knowledge base.
"""

from typing import TypedDict
from anthropic import Anthropic
from src.rag.retriever import retrieve_icd10, retrieve_cpt
import json
import re

client = Anthropic()


class CodeAssignment(TypedDict):
    code: str
    description: str
    confidence: float
    source_citation: str


class CodingResult(TypedDict):
    icd10_codes: list[CodeAssignment]
    cpt_codes: list[CodeAssignment]
    overall_confidence: float
    coding_rationale: str
    escalate_to_human: bool
    escalation_reason: str | None


class CodingAgentState(TypedDict):
    raw_notes: str
    patient_id: str
    proposed_procedure: str
    payer: str
    extracted_entities: dict
    coding_result: CodingResult | None
    error: str | None


CONFIDENCE_THRESHOLD = 0.75  # Below this → escalate to human


CODING_SYSTEM_PROMPT = """You are a certified medical coding agent for an Indian healthcare system.
Your job is to assign the correct ICD-10-CM diagnosis codes and CPT procedure codes.

You will be given:
1. Clinical notes with extracted entities
2. Retrieved ICD-10 and CPT code candidates from our knowledge base

Rules:
- Only assign codes that are clearly supported by the clinical evidence
- Assign a confidence score (0.0 to 1.0) for each code
- If you are not confident (< 0.75), say so explicitly
- Always cite the specific clinical evidence for each code
- Prefer more specific codes over general codes
- For Indian context: align with MOHFW coding guidelines where applicable

Return valid JSON with this structure:
{
  "icd10_codes": [{"code": "...", "description": "...", "confidence": 0.0, "source_citation": "..."}],
  "cpt_codes": [{"code": "...", "description": "...", "confidence": 0.0, "source_citation": "..."}],
  "overall_confidence": 0.0,
  "coding_rationale": "...",
  "escalate_to_human": false,
  "escalation_reason": null
}

COMPLIANCE: Never assign a code you are not confident about. It is better to escalate than to code incorrectly."""


def run_coding_agent(state: CodingAgentState) -> CodingAgentState:
    """
    Runs the coding agent. Uses RAG to retrieve relevant codes,
    then uses LLM to assign and score them.
    """
    print("[CodingAgent] Retrieving code candidates from knowledge base...")

    entities = state.get("extracted_entities", {})
    symptoms = entities.get("symptoms", [])
    procedures = [state["proposed_procedure"]] + entities.get("procedures_mentioned", [])

    # RAG retrieval
    icd10_candidates = retrieve_icd10(symptoms)
    cpt_candidates = retrieve_cpt(procedures)

    print(f"[CodingAgent] Retrieved {len(icd10_candidates)} ICD-10 candidates, "
          f"{len(cpt_candidates)} CPT candidates")

    prompt = f"""Clinical Notes:
{state['raw_notes']}

Extracted Entities:
{json.dumps(entities, indent=2)}

Proposed Procedure: {state['proposed_procedure']}

ICD-10 Candidates from Knowledge Base:
{json.dumps(icd10_candidates, indent=2)}

CPT Candidates from Knowledge Base:
{json.dumps(cpt_candidates, indent=2)}

Assign the most appropriate ICD-10 and CPT codes. Apply the confidence threshold rule."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=2048,
            system=CODING_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )

        raw_output = response.content[0].text
        cleaned = re.sub(r"```(?:json)?", "", raw_output).strip()
        coding_result: CodingResult = json.loads(cleaned)

        # Enforce confidence gate — override LLM if it missed it
        overall_conf = coding_result.get("overall_confidence", 0.0)
        if overall_conf < CONFIDENCE_THRESHOLD and not coding_result.get("escalate_to_human"):
            coding_result["escalate_to_human"] = True
            coding_result["escalation_reason"] = (
                f"Overall confidence {overall_conf:.2f} below threshold {CONFIDENCE_THRESHOLD}"
            )

        print(f"[CodingAgent] Assigned {len(coding_result['icd10_codes'])} ICD-10 codes, "
              f"{len(coding_result['cpt_codes'])} CPT codes. "
              f"Confidence: {overall_conf:.2f}. "
              f"Escalate: {coding_result['escalate_to_human']}")

        return {**state, "coding_result": coding_result, "error": None}

    except json.JSONDecodeError as e:
        return {**state, "error": f"CodingAgent JSON parse failed: {str(e)}"}
    except Exception as e:
        return {**state, "error": f"CodingAgent failed: {str(e)}"}
