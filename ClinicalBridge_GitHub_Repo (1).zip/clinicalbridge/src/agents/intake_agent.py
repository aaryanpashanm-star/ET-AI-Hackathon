"""
ClinicalBridge - Intake Agent
Parses clinical notes and extracts structured clinical entities.
"""

from typing import TypedDict, Annotated
from anthropic import Anthropic
import json
import re

client = Anthropic()


class ClinicalEntities(TypedDict):
    symptoms: list[str]
    medications: list[str]
    procedures_mentioned: list[str]
    duration: str
    severity: str
    patient_age: str | None
    vitals: dict


class IntakeAgentState(TypedDict):
    raw_notes: str
    patient_id: str
    proposed_procedure: str
    payer: str
    extracted_entities: ClinicalEntities | None
    error: str | None


INTAKE_SYSTEM_PROMPT = """You are a clinical NER (Named Entity Recognition) agent for an Indian healthcare
compliance system. Your job is to extract structured clinical information from doctor notes.

Extract ONLY what is explicitly stated in the notes. Never infer or hallucinate clinical details.
If something is not mentioned, mark it as null or empty list.

Return a valid JSON object with these exact keys:
- symptoms: list of symptoms mentioned
- medications: list of medications mentioned (generic names preferred)
- procedures_mentioned: list of any procedures mentioned in notes
- duration: how long symptoms have been present (e.g. "3 days", "2 weeks", "unknown")
- severity: "mild" | "moderate" | "severe" | "unknown"
- patient_age: age if mentioned, else null
- vitals: dict of any vitals mentioned (BP, HR, SpO2, etc.)

COMPLIANCE NOTE: Do not include patient name or address in output."""


def run_intake_agent(state: IntakeAgentState) -> IntakeAgentState:
    """
    Runs the intake agent to parse clinical notes and extract entities.
    Adds extracted entities to state.
    """
    print("[IntakeAgent] Parsing clinical notes...")

    try:
        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=1024,
            system=INTAKE_SYSTEM_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": f"Extract clinical entities from these notes:\n\n{state['raw_notes']}"
                }
            ]
        )

        raw_output = response.content[0].text

        # Strip markdown code fences if present
        cleaned = re.sub(r"```(?:json)?", "", raw_output).strip()
        entities: ClinicalEntities = json.loads(cleaned)

        print(f"[IntakeAgent] Extracted {len(entities.get('symptoms', []))} symptoms, "
              f"{len(entities.get('medications', []))} medications")

        return {
            **state,
            "extracted_entities": entities,
            "error": None
        }

    except json.JSONDecodeError as e:
        print(f"[IntakeAgent] JSON parse error: {e}")
        return {**state, "error": f"IntakeAgent JSON parse failed: {str(e)}"}
    except Exception as e:
        print(f"[IntakeAgent] Error: {e}")
        return {**state, "error": f"IntakeAgent failed: {str(e)}"}


if __name__ == "__main__":
    # Quick smoke test
    test_state: IntakeAgentState = {
        "raw_notes": (
            "55 year old male presents with chest pain radiating to left arm for 2 days. "
            "Shortness of breath on exertion. BP 150/95 mmHg, HR 88 bpm, SpO2 96%. "
            "Currently on Aspirin 75mg, Atorvastatin 40mg. "
            "History of hypertension for 5 years."
        ),
        "patient_id": "P-TEST-001",
        "proposed_procedure": "Coronary angiography",
        "payer": "PMJAY",
        "extracted_entities": None,
        "error": None
    }

    result = run_intake_agent(test_state)
    print(json.dumps(result["extracted_entities"], indent=2))
