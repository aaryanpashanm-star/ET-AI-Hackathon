"""
ClinicalBridge - FastAPI Application
Main entrypoint for the prior authorization API.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
import time
import uuid

from src.agents.intake_agent import run_intake_agent
from src.agents.coding_agent import run_coding_agent
from src.agents.auth_agent import run_auth_agent
from src.agents.audit_agent import run_audit_agent, get_audit_trail, verify_chain

app = FastAPI(
    title="ClinicalBridge API",
    description="AI-powered prior authorization and medical coding with compliance guardrails",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request / Response Schemas ────────────────────────────────────────────────

class AuthorizationRequest(BaseModel):
    patient_id: str = Field(..., description="Anonymized patient identifier")
    clinical_notes: str = Field(..., min_length=20, description="Clinical notes from physician")
    proposed_procedure: str = Field(..., description="Procedure being requested")
    payer: str = Field(..., description="Payer name (e.g. PMJAY, Star Health)")
    provider_id: str = Field(..., description="Hospital/clinic identifier")


class AuthorizationResponse(BaseModel):
    case_id: str
    decision: str
    icd10_codes: list[dict]
    cpt_codes: list[dict]
    confidence: float
    conditions: list[str]
    denial_reasons: list[str]
    escalated_to_human: bool
    escalation_reason: Optional[str]
    financial_threshold_flag: bool
    audit_trail_id: str
    processing_time_ms: int
    disclaimer: str = "SUPPORT TOOL ONLY. This output does not constitute a clinical prescription or final payer decision. All decisions require authorized human review."


# ── Routes ────────────────────────────────────────────────────────────────────

@app.post("/api/v1/authorize", response_model=AuthorizationResponse)
async def authorize(request: AuthorizationRequest):
    """
    Submit a case for AI-assisted prior authorization.
    Runs the full 4-agent pipeline and returns a compliance-gated decision.
    """
    start_time = time.time()
    case_id = f"CB-{time.strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

    # Build initial state
    state = {
        "raw_notes": request.clinical_notes,
        "patient_id": request.patient_id,
        "proposed_procedure": request.proposed_procedure,
        "payer": request.payer,
        "extracted_entities": None,
        "coding_result": None,
        "auth_result": None,
        "error": None
    }

    # Run pipeline: Intake → Coding → Auth
    state = run_intake_agent(state)
    if state.get("error"):
        raise HTTPException(status_code=500, detail=f"Intake failed: {state['error']}")

    state = run_coding_agent(state)
    if state.get("error"):
        raise HTTPException(status_code=500, detail=f"Coding failed: {state['error']}")

    state = run_auth_agent(state)
    if state.get("error"):
        raise HTTPException(status_code=500, detail=f"Auth failed: {state['error']}")

    # Log audit trail
    audit_trail_id = run_audit_agent(state, case_id)

    processing_ms = int((time.time() - start_time) * 1000)

    coding = state["coding_result"]
    auth = state["auth_result"]

    return AuthorizationResponse(
        case_id=case_id,
        decision=auth["decision"],
        icd10_codes=coding.get("icd10_codes", []),
        cpt_codes=coding.get("cpt_codes", []),
        confidence=auth.get("confidence", 0.0),
        conditions=auth.get("conditions", []),
        denial_reasons=auth.get("denial_reasons", []),
        escalated_to_human=auth.get("escalate_to_human", False),
        escalation_reason=auth.get("escalation_reason"),
        financial_threshold_flag=auth.get("financial_threshold_flag", False),
        audit_trail_id=audit_trail_id,
        processing_time_ms=processing_ms
    )


@app.get("/api/v1/audit/{case_id}")
async def get_audit(case_id: str):
    """Retrieve the full immutable audit trail for a case."""
    trail = get_audit_trail(case_id)
    if not trail:
        raise HTTPException(status_code=404, detail="Audit trail not found")

    is_valid, message = verify_chain(case_id)
    return {
        "case_id": case_id,
        "chain_valid": is_valid,
        "chain_message": message,
        "records": trail
    }


@app.get("/api/v1/health")
async def health():
    return {"status": "healthy", "service": "ClinicalBridge", "version": "1.0.0"}
