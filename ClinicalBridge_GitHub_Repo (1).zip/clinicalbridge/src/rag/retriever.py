"""
ClinicalBridge - RAG Retriever
Retrieves relevant ICD-10 codes, CPT codes, and payer policy sections
from ChromaDB vector store.
"""

import chromadb
from chromadb.config import Settings
from pathlib import Path

CHROMA_PATH = "data/chroma_db"

_client: chromadb.Client | None = None


def _get_client() -> chromadb.Client:
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(
            path=CHROMA_PATH,
            settings=Settings(anonymized_telemetry=False)
        )
    return _client


def retrieve_icd10(symptoms: list[str], n_results: int = 5) -> list[dict]:
    """
    Retrieves the most relevant ICD-10-CM codes for the given symptoms.
    Returns a list of {code, description, relevance_score}.
    """
    if not symptoms:
        return []

    try:
        client = _get_client()
        collection = client.get_collection("icd10_codes")

        query_text = " ".join(symptoms)
        results = collection.query(
            query_texts=[query_text],
            n_results=n_results,
            include=["documents", "metadatas", "distances"]
        )

        candidates = []
        for i, doc in enumerate(results["documents"][0]):
            metadata = results["metadatas"][0][i]
            distance = results["distances"][0][i]
            candidates.append({
                "code": metadata.get("code", ""),
                "description": doc,
                "relevance_score": round(1 - distance, 3)
            })

        return candidates

    except Exception as e:
        print(f"[Retriever] ICD-10 retrieval failed (using fallback): {e}")
        # Fallback for demo when DB not initialized
        return _icd10_fallback(symptoms)


def retrieve_cpt(procedures: list[str], n_results: int = 5) -> list[dict]:
    """
    Retrieves the most relevant CPT procedure codes.
    """
    if not procedures:
        return []

    try:
        client = _get_client()
        collection = client.get_collection("cpt_codes")

        query_text = " ".join(procedures)
        results = collection.query(
            query_texts=[query_text],
            n_results=n_results,
            include=["documents", "metadatas", "distances"]
        )

        candidates = []
        for i, doc in enumerate(results["documents"][0]):
            metadata = results["metadatas"][0][i]
            distance = results["distances"][0][i]
            candidates.append({
                "code": metadata.get("code", ""),
                "description": doc,
                "relevance_score": round(1 - distance, 3)
            })

        return candidates

    except Exception as e:
        print(f"[Retriever] CPT retrieval failed (using fallback): {e}")
        return _cpt_fallback(procedures)


def retrieve_payer_policy(payer: str, cpt_codes: list[str], icd10_codes: list[str],
                          n_results: int = 5) -> list[dict]:
    """
    Retrieves relevant payer policy sections for the given codes.
    """
    try:
        client = _get_client()
        collection = client.get_collection("payer_policies")

        query_text = f"{payer} {' '.join(cpt_codes)} {' '.join(icd10_codes)}"
        results = collection.query(
            query_texts=[query_text],
            n_results=n_results,
            where={"payer": payer} if payer else None,
            include=["documents", "metadatas", "distances"]
        )

        policy_docs = []
        for i, doc in enumerate(results["documents"][0]):
            metadata = results["metadatas"][0][i]
            distance = results["distances"][0][i]
            policy_docs.append({
                "payer": metadata.get("payer", payer),
                "section": metadata.get("section", ""),
                "content": doc,
                "relevance_score": round(1 - distance, 3)
            })

        return policy_docs

    except Exception as e:
        print(f"[Retriever] Payer policy retrieval failed (using fallback): {e}")
        return _policy_fallback(payer, cpt_codes)


# ── Fallback data for demo when ChromaDB is not initialized ──────────────────

def _icd10_fallback(symptoms: list[str]) -> list[dict]:
    """Hardcoded fallback ICD-10 codes for demo."""
    symptom_str = " ".join(symptoms).lower()
    if any(w in symptom_str for w in ["chest pain", "cardiac", "heart"]):
        return [
            {"code": "I25.10", "description": "Atherosclerotic heart disease of native coronary artery without angina pectoris", "relevance_score": 0.92},
            {"code": "R07.9", "description": "Chest pain, unspecified", "relevance_score": 0.88},
            {"code": "I10", "description": "Essential (primary) hypertension", "relevance_score": 0.75},
        ]
    return [{"code": "R69", "description": "Illness, unspecified", "relevance_score": 0.50}]


def _cpt_fallback(procedures: list[str]) -> list[dict]:
    """Hardcoded fallback CPT codes for demo."""
    proc_str = " ".join(procedures).lower()
    if "angiograph" in proc_str:
        return [
            {"code": "93454", "description": "Catheter placement in coronary artery(s) for coronary angiography", "relevance_score": 0.95},
            {"code": "93458", "description": "Left heart catheterization including left ventriculography", "relevance_score": 0.80},
        ]
    return [{"code": "99213", "description": "Office or outpatient visit, established patient, moderate complexity", "relevance_score": 0.50}]


def _policy_fallback(payer: str, cpt_codes: list[str]) -> list[dict]:
    """Hardcoded fallback policy for demo."""
    return [
        {
            "payer": payer,
            "section": "Cardiac Catheterization - Section 4.2.1",
            "content": (
                f"{payer} requires prior authorization for cardiac catheterization (CPT 93454). "
                "Criteria: (1) Positive stress test OR (2) unstable angina with ECG changes. "
                "Required documentation: referring physician letter, recent ECG, stress test report."
            ),
            "relevance_score": 0.90
        }
    ]
